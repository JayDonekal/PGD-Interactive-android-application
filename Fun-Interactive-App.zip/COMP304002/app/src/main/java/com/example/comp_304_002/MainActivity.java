package com.example.comp_304_002;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    String[] activities = {"Exercise 2","Exercise 2","Exercises 3"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView listView = (ListView)findViewById(R.id.list);

        activities = getResources().getStringArray(R.array.activities);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,activities);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(this);
    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
    {
        Intent j=null;
        switch (i)
        {
            case 0:
                j = new Intent(this, Exercise1Activity.class);
                break;
            case 1:
                j = new Intent(this, Exercise2Activity.class);
                break;
            case 2:
                j = new Intent(this, Exercise3Activity.class);
                break;
        }
        startActivity(j);
    }
}