package com.example.comp_304_002;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class Exercise1Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    ImageView reusableImageView;
    TextView textViewX, textViewY;
    Spinner spinner;

    // define the start/end positions of each step
    int startx = 10;
    int starty = 10;
    int endx = 10;
    int endy = 10;

    // values to prevent the brush from going out of bounds
    int minX = 0;
    int minY = 0;
    int maxX = 0;
    int maxY = 0;

    // defined objects for drawing
    Paint paint;
    Bitmap bitmap;
    Canvas canvas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise1);

        // initialize new paint object to draw lines
        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(20);


        // store the necessary views
        reusableImageView = (ImageView) findViewById(R.id.imageViewForDrawing);
        textViewX = (TextView) findViewById(R.id.textViewX);
        textViewY = (TextView) findViewById(R.id.textViewY);
        spinner = (Spinner) findViewById(R.id.spinnerLineThickness);

        // array of different line widths
        Integer[] strokeWidths = {1, 5, 10, 15, 20, 30, 50, 100};

        // define ArrayAdapter using the  array and a default spinner layout
        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item, strokeWidths);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // giving the spinner a listener
        spinner.setOnItemSelectedListener(this);
        spinner.setSelection(4);

        // create a bitmap that has the screen's width and half the screen's height
        Point screenSize = new Point();
        this.getWindowManager().getDefaultDisplay().getSize(screenSize);
        bitmap = Bitmap.createBitmap(screenSize.x, screenSize.y / 2, Bitmap.Config.ARGB_8888);

        // set maxX and maxY
        maxX = screenSize.x;
        maxY = screenSize.y / 2;

        // create a canvas using the bitmap we just created
        canvas = new Canvas(bitmap);

        // setting the bitmap as content view for the image
        reusableImageView.setImageBitmap(bitmap);

        clearCanvas(reusableImageView);
    }


    // clears the canvas and resets the positions
    public void clearCanvas(View v) {
        canvas.drawColor(Color.LTGRAY);
        startx = 10;
        starty = 10;
        endx = 10;
        endy = 10;
    }


    // draws a line according to the current specifications
    public void drawLine(Canvas canvas) {

        // ensure brush stays on canvas
        endx = Math.min(Math.max(endx, minX), maxX);
        endy = Math.min(Math.max(endy, minY), maxY);

        // set on-screen information
        textViewX.setText("X = " + String.valueOf(endx));
        textViewY.setText("Y = " + String.valueOf(endy));

        // draw line and update start position
        canvas.drawLine(startx, starty, endx, endy, paint);
        startx = endx;
        starty = endy;
    }

    // handles a click event from the arrow buttons
    public boolean onArrowClick(View view) {
        switch (view.getId()) {
            case R.id.imageButtonDown:

                endy = endy + 5;
                drawLine(canvas);

                return true;

            case R.id.imageButtonUp:

                endy = endy - 5;
                drawLine(canvas);

                return true;

            case R.id.imageButtonLeft:

                endx = endx - 5;
                drawLine(canvas);

                return true;

            case R.id.imageButtonRight:

                endx = endx + 5;
                drawLine(canvas);

                return true;

        }
        return false;
    }

    //Using the DPAD keys to move
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_DOWN:

                endy = endy + 5;
                drawLine(canvas);

                return true;

            case KeyEvent.KEYCODE_DPAD_UP:

                endy = endy - 5;
                drawLine(canvas);

                return true;

            case KeyEvent.KEYCODE_DPAD_LEFT:

                endx = endx - 5;
                drawLine(canvas);

                return true;

            case KeyEvent.KEYCODE_DPAD_RIGHT:

                endx = endx + 5;
                drawLine(canvas);

                return true;

        }
        return false;
    }

    public void onRadioButtonClicked(View view) {

        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radioButtonRed:
                if (checked)
                    paint.setColor(Color.RED);
                break;
            case R.id.radioButtonGreen:
                if (checked)
                    paint.setColor(Color.GREEN);
                break;
            case R.id.radioButtonBlue:
                if (checked)
                    paint.setColor(Color.BLUE);
                break;
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

        // sets line width according to the item selected in spinner
        paint.setStrokeWidth((int) parent.getItemAtPosition(pos));
    }

    public void onNothingSelected(AdapterView<?> parent) {

    }
}